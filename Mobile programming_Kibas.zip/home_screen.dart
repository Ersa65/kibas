import 'package:flutter/material.dart';
import 'package:myapp/learn_screen.dart'; // Impor LearnScreen

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE7E497),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Kilas Bahasa Lampung',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFA50000),
                ),
              ),
              const SizedBox(height: 20),
              _buildGreetingCard(),
              const SizedBox(height: 40),
              // Level 1 Card - Now tappable
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LearnScreen()),
                  );
                },
                child: _buildLevelIndicator(
                  level: '1',
                  color: const Color(0xFFA50000),
                  imagePath: 'assets/images/tiger.png',
                ),
              ),
              const SizedBox(height: 20),
              _buildLevelIndicator(
                level: '2',
                color: const Color(0xFF4C4545),
                imagePath: 'assets/images/elephant.png',
                isLeftAligned: false,
              ),
              const SizedBox(height: 20),
              _buildLevelIndicator(
                level: '3',
                color: const Color(0xFF4C4545),
                imagePath: 'assets/images/rhino.png',
              ),
            ],
          ),  
        ),
      ),
    );
  }

  Widget _buildGreetingCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFDDB200),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 24,
            backgroundColor: Colors.white,
            child: Padding(
              padding: EdgeInsets.all(4.0),
              child: Image(image: AssetImage('assets/images/logo.png')),
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'Tabik Pun 👋',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFFA50000),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLevelIndicator({ 
    required String level,
    required Color color,
    required String imagePath,
    bool isLeftAligned = true,
  }) {
    final levelCircle = Container(
      width: 120,
      height: 120,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          'Level $level',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );

    final animalImage = Image.asset(
      imagePath,
      width: 100,
      height: 100,
      errorBuilder: (context, error, stackTrace) {
        return const Icon(Icons.pets, size: 50, color: Colors.grey);
      },
    );

    return Align(
      alignment: isLeftAligned ? Alignment.centerLeft : Alignment.centerRight,
      child: SizedBox(
        width: 200,
        height: 120,
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (isLeftAligned) ...[
              Positioned(left: 0, child: levelCircle),
              Positioned(right: 0, bottom: 0, child: animalImage),
            ] else ...[
              Positioned(right: 0, child: levelCircle),
              Positioned(left: 0, bottom: 0, child: animalImage),
            ]
          ],
        ),
      ),
    );
  }
}
