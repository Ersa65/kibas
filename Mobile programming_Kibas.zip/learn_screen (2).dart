
import 'package:flutter/material.dart';

// Data model for the image-based quiz
class _Option {
  final String name;
  final String imagePath;

  _Option(this.name, this.imagePath);
}

// Data model for the word completion quiz
class _Question {
  final String title;
  final String word;
  final String correctAnswer;
  final Map<int, String> prefilledLetters;

  _Question({
    required this.title,
    required this.word,
    required this.correctAnswer,
    this.prefilledLetters = const {},
  });
}

class LearnScreen extends StatefulWidget {
  const LearnScreen({super.key});

  @override
  State<LearnScreen> createState() => _LearnScreenState();
}

class _LearnScreenState extends State<LearnScreen> {
  int _questionIndex = 0;

  // Data for the first question (image-based)
  final List<_Option> _options = [
    _Option('tangan', 'assets/images/tangan.png'),
    _Option('kaki', 'assets/images/kaki.png'),
    _Option('telinga', 'assets/images/telinga.png'),
    _Option('rambut', 'assets/images/rambut.png'),
  ];
  final String _correctImageAnswer = 'tangan';
  _Option? _selectedOption;
  bool? _isCorrect1;

  // Data for the second question (word completion)
  final _question2 = _Question(
    title: 'Lengkapi kosa kata di bawah ini!',
    word: 'RAMBUT',
    correctAnswer: 'BUWOK',
    prefilledLetters: {0: 'B', 3: 'O'},
  );
  String _input = '';
  bool? _isCorrect2;

  void _onOptionSelected(_Option option) {
    if (_selectedOption != null) return;
    setState(() {
      _selectedOption = option;
      _isCorrect1 = option.name == _correctImageAnswer;
    });
  }

  void _onCharInput(String char) {
    int emptySlots = _question2.correctAnswer.length - _question2.prefilledLetters.length;
    if (_input.length < emptySlots) {
      setState(() {
        _input += char;
      });
    }
  }

  void _onBackspace() {
    if (_input.isNotEmpty) {
      setState(() {
        _input = _input.substring(0, _input.length - 1);
      });
    }
  }

  void _checkAnswer2() {
    // Build the full word from pre-filled and user input
    List<String> answerList = List.filled(_question2.correctAnswer.length, '');
    int inputIndex = 0;

    for (int i = 0; i < _question2.correctAnswer.length; i++) {
      if (_question2.prefilledLetters.containsKey(i)) {
        answerList[i] = _question2.prefilledLetters[i]!;
      } else {
        if (inputIndex < _input.length) {
          answerList[i] = _input[inputIndex];
          inputIndex++;
        }
      }
    }
    String finalAnswer = answerList.join('');

    setState(() {
      _isCorrect2 = (finalAnswer.toUpperCase() == _question2.correctAnswer);
    });
  }


  void _reset() {
    setState(() {
      // Reset first question
      _selectedOption = null;
      _isCorrect1 = null;
      
      // Reset second question
      _input = '';
      _isCorrect2 = null;
    });
  }

  void _next() {
    setState(() {
      if (_questionIndex == 0) {
        _questionIndex = 1;
        _reset(); // Reset state for the next question
      } else {
        // End of quiz, navigate back or to a results screen
        _questionIndex = 0;
        _reset();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE7E497),
      body: SafeArea(
        child: _questionIndex == 0 ? _buildQuestion1() : _buildQuestion2(),
      ),
    );
  }

  // ============== UI for Question 1 (Image Quiz) =============="
  Widget _buildQuestion1() {
    return Column(
      children: [
        _buildHeader(0.3),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'CULUK',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF3D3A3A),
                  ),
                ),
                const SizedBox(height: 30),
                _buildImageGrid(),
              ],
            ),
          ),
        ),
        if (_selectedOption != null) _buildFeedbackBanner1(),
      ],
    );
  }

  Widget _buildImageGrid() {
    return Expanded(
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.9,
        ),
        itemCount: _options.length,
        itemBuilder: (context, index) {
          final option = _options[index];
          bool isSelected = _selectedOption?.name == option.name;
          Color borderColor = Colors.transparent;
          if (isSelected) {
            borderColor = _isCorrect1 == true ? Colors.green : Colors.red;
          }
          return GestureDetector(
            onTap: () => _onOptionSelected(option),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFddb200),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: borderColor, width: isSelected ? 4 : 0),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 8)],
              ),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Image.asset(option.imagePath, fit: BoxFit.contain),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFeedbackBanner1() {
    final bool isCorrect = _isCorrect1 ?? false;
    return _buildFeedbackBanner(
      feedbackText: isCorrect ? 'Benar!' : 'Salah, Coba Lagi',
      subText: '',
      bannerColor: isCorrect ? const Color(0xFF2E7D32) : const Color(0xFFC62828),
      buttonText: isCorrect ? 'LANJUT' : 'COBA LAGI',
      onButtonPressed: isCorrect ? _next : _reset,
    );
  }

  // ============== UI for Question 2 (Word Completion) ==============
  Widget _buildQuestion2() {
    return Column(
      children: [
        _buildHeader(0.6),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  _question2.title,
                  style: const TextStyle(fontSize: 18, color: Color(0xFF3D3A3A)),
                ),
                const SizedBox(height: 10),
                Text(
                  _question2.word,
                  style: const TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF3D3A3A),
                  ),
                ),
                const SizedBox(height: 30),
                _buildInputBoxes(),
                const Spacer(),
                _buildKeyboard(),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _input.length == (_question2.correctAnswer.length - _question2.prefilledLetters.length)
                        ? _checkAnswer2
                        : null, // Disable button until all letters are filled
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFDDB200),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    child: const Text('CHECK'),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
        if (_isCorrect2 != null) _buildFeedbackBanner2(),
      ],
    );
  }

  Widget _buildInputBoxes() {
    List<Widget> boxes = [];
    int inputIndex = 0;
    for (int i = 0; i < _question2.correctAnswer.length; i++) {
      String text;
      if (_question2.prefilledLetters.containsKey(i)) {
        text = _question2.prefilledLetters[i]!;
      } else {
        if (inputIndex < _input.length) {
          text = _input[inputIndex];
          inputIndex++;
        } else {
          text = ''; // This is an empty, user-fillable slot
        }
      }

      boxes.add(
        Container(
          width: 50,
          height: 50,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: const Color(0xFFDDB200),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      );
    }
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: boxes,
    );
  }

  Widget _buildKeyboard() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: 'QWERTYUIOP'.split('').map((e) => _buildKey(e)).toList(),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: 'ASDFGHJKL'.split('').map((e) => _buildKey(e)).toList(),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ... 'ZXCVBNM'.split('').map((e) => _buildKey(e)).toList(),
            _buildKey('⌫', onTap: _onBackspace),
          ],
        ),
      ],
    );
  }

  Widget _buildKey(String char, {VoidCallback? onTap}) {
    // Disable key if input is already full, unless it's the backspace key
    final bool isInputFull = _input.length >= (_question2.correctAnswer.length - _question2.prefilledLetters.length);
    final bool isBackspace = char == '⌫';
    final bool isDisabled = isInputFull && !isBackspace;

    return Expanded(
      child: InkWell(
        onTap: isDisabled ? null : (onTap ?? () => _onCharInput(char)),
        child: Opacity(
          opacity: isDisabled ? 0.5 : 1.0,
          child: Container(
            height: 50,
            margin: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                char,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeedbackBanner2() {
    final bool isCorrect = _isCorrect2 ?? false;
    return _buildFeedbackBanner(
      feedbackText: isCorrect ? 'BENAR' : 'SALAH',
      subText: isCorrect ? '' : _question2.correctAnswer,
      bannerColor: isCorrect ? const Color(0xFF2E7D32) : const Color(0xFFC62828),
      buttonText: isCorrect ? 'SELESAI' : 'COBA LAGI',
      onButtonPressed: isCorrect ? _next : _reset,
    );
  }

  // ============== Common Widgets ==============

  Widget _buildHeader(double progress) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 16.0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Color(0xFF3D3A3A), size: 30),
            onPressed: () => Navigator.of(context).pop(),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 12,
                backgroundColor: Colors.black12,
                color: const Color(0xFF615E5E),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeedbackBanner({
    required String feedbackText,
    required String subText,
    required Color bannerColor,
    required String buttonText,
    required VoidCallback onButtonPressed,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 25),
      decoration: BoxDecoration(color: bannerColor),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            feedbackText,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          if (subText.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Text(
                subText,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 18,
                ),
              ),
            ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onButtonPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: bannerColor,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              child: Text(buttonText),
            ),
          ),
        ],
      ),
    );
  }
}
